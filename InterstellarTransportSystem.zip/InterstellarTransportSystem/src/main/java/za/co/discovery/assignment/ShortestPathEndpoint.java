package za.co.discovery.assignment;

import org.springframework.ws.server.endpoint.annotation.Endpoint;

@Endpoint
public class ShortestPathEndpoint {

}